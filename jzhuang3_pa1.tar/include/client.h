/***
 * @jzhuang3_assignment1
 * @author  JingJing Zhuang <jzhuang3@buffalo.edu> 
***/
#ifndef CLIENT_H
#define CLIENT_H
#include <iostream>

using namespace std;

class client
{
public:
    client(char* port);
};

#endif