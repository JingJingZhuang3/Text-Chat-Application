/***
 * @jzhuang3_assignment1
 * @author  JingJing Zhuang <jzhuang3@buffalo.edu> 
***/
#ifndef SERVER_H
#define SERVER_H
#include <iostream>

using namespace std;

class server
{
public:
    server(int port);
};

#endif